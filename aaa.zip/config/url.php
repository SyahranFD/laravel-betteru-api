<?php

return [
    'localhost' => env('URL_LOCALHOST'),
    'hosting' => env('URL_HOSTING'),
];
